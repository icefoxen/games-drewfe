# resource.rb
# Resource system.
# It basically makes sure that we don't have anything, like an image or
# config file, in memory more than once.
# Saves efficiency, and presents a unified interface to Getting Stuff.
