# error.rb
# Exceptions and stuff.


class FEException < Exception
end
