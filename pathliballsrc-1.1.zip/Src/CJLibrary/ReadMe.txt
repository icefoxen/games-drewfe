Copyright � 1998-1999 CodeJock.com, All Rights Reserved.
webmaster@codejock.com
http://www.codejock.com

==========================================================
TERMS OF USE:
==========================================================

The CJLibrary is Copyright � 1998-1999 CodeJock.com, and may be used in compiled form in any way you 
desire, PROVIDING it is not sold for profit either whole or inpart, without the authors expressed written
consent, and the following terms and conditions are met:

1. This notice and the author's name and all copyright information shall remain intact in all associated 
source files. Any source code found in the CJLibrary that was not written by Kirk Stowell is the sole 
property of said contributing author, and may be subject to that authors terms and conditions of usage 
and is herein to be referred to as contribution. All contributions have been added to enhance the library 
functionality and are considered as freeware by the contributing authors. Where possible the 
contributing authors name and URL where the original unmodified source can be found, has been 
included in the source files header. The contribution is by no means included as part of any registration 
fee, and are merely included to complement the existing library, and are in themselves a separate 
entity. Such contributions may be maintained or enhanced by developers at CodeJock.com to suit a 
particular need or purpose, including correcting problems with the code. All contributions have been 
added with the contributing author's permission.

2. The CJLibrary is to be considered freeware for non-commercial use only, and is considered shareware 
for commercial use. Commercial developers may use the library and source code for no more than 30 
days without registration. During this 30 day period, the developer may use the library for evaluation 
purposes only, in house, without distribution of any source in any format either ASCII or binary. After 
which the developer must register or discontinue use of the library. If the library is to be used for non-
commercial purposes, then a statement along the lines of "Portions Copyright � 1998-1999 
CodeJock.com" must be included in the "Splash Screen", "About Box or Printed Documentation". 

3. Non-commercial use is considered to be an application that is distributed as freeware or free of cost, or 
used by any non-profit organization such as a University or student for educational purposes only. 
Commercial use is considered to be any application that has been developed for an organization or 
company that is to be distributed or sold for profit, or the organization or company is profit based and 
the application is to be used in-house. 

This software is provided "as is" without express or implied warranty. Use it at your own risk! The author(s) 
accept no liability for any damage/loss of business that this product may cause.