//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CJResource.rc
//
#define IDR_POPUP_HEX_EDIT              103
#define IDS_HIDE                        5000
#define IDC_NODRAGGING                  5001
#define IDS_NAME                        5001
#define IDS_EXPAND                      5002
#define IDC_DRAGGING                    5003
#define IDS_SIZE                        5003
#define IDS_CONTRACT                    5004
#define IDC_HANDCUR                     5005
#define IDS_TYPE                        5005
#define IDB_BUTTON_IMAGES               5006
#define IDS_MODIFIED                    5006
#define IDC_TAB_CONTROL                 5007
#define IDS_REGKEY                      5007
#define IDR_CBAR_POPUP                  5008
#define IDS_INVALID_VER                 5008
#define IDC_URL_CODEJOCKEY              5009
#define IDS_WIN_PLACEMENT               5009
#define IDB_BTN_EXPLORER                5010
#define IDS_COLOR_AUTO                  5010
#define IDM_CBAR_MENU                   5011
#define IDS_COLOR_CUST                  5011
#define IDC_BUTTON_HIDE                 5012
#define IDS_SECTION                     5012
#define IDC_BUTTON_MINI                 5013
#define IDS_ENTRY                       5013
#define IDC_BAR_BUTTON                  5014
#define IDS_REMOVEITEM                  5014
#define IDC_BAR_CAPTION                 5015
#define IDS_RENAMEITEM                  5015
#define IDB_BTN_ARROW                   5016
#define ID_GFX_LARGEICON                5017
#define ID_GFX_SMALLICON                5018
#define ID_GFX_REMOVEITEM               5019
#define IDC_VSPLITBAR                   5020
#define ID_GFX_RENAMEITEM               5021
#define IDC_HSPLITBAR                   5022
#define IDR_GFXOUTBAR                   5023
#define IDR_POPUP_TOOLBAR               5024
#define IDS_SETTINGS                    5025
#define IDS_TBAR_SETTINGS               5026
#define ID_POPUP_CUSTOMIZE              5027
#define IDS_WNDPOS                      5028
#define IDC_CAPT_BUTTON                 5029
#define IDB_PUSHPIN                     5030
#define IDC_LEFTBUTTON                  5031
#define IDC_RIGHTBUTTON                 5032
#define IDC_HOMEBUTTON                  5033
#define IDC_ENDBUTTON                   5034

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        5032
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         5030
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
