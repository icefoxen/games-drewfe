#if !defined(AFX_NEWDLG_H__A9F9DC57_5D74_4756_A4C5_D4918D69BFC8__INCLUDED_)
#define AFX_NEWDLG_H__A9F9DC57_5D74_4756_A4C5_D4918D69BFC8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NewDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNewDlg dialog

class CNewDlg : public CDialog
{
// Construction
public:
	CNewDlg(CWnd* pParent = NULL, char mode = 0);   // standard constructor

// Dialog Data
    
    //{{AFX_DATA(CNewDlg)
	enum { IDD = IDD_NEWDLG };
	CEdit	m_MixCoefCtrl;
	int		m_HeapSize;
	int		m_MPCPT;
	int		m_MaxReq;
	int		m_MSX;
	int		m_MSY;
	int		m_MaxWalkers;
	int		m_MAXTC;
	int		m_HC;
	int		m_FSC;
	int		m_DC;
	int		m_BFS;
	int		m_BFR;
	int		m_BC;
	int		m_ND;
	int		m_SBC;
	int		m_WBC;
	int		m_WT;
	int		m_FSB;
	int		m_HeurSel;
	float	m_MixCoef;
	int		m_MixFuncSel;
	int		m_DT;
	//}}AFX_DATA

  char  m_Mode;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNewDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNewDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeMixfunc();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NEWDLG_H__A9F9DC57_5D74_4756_A4C5_D4918D69BFC8__INCLUDED_)
