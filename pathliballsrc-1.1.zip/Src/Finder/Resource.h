//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Finder.rc
//
#define IDD_ABOUTBOX                    100
#define ID_DEBUGLIST                    101
#define IDD_MAINBAR                     102
#define IDC_FLATTAB                     103
#define ID_WV_POS                       103
#define ID_VIEW_OUTPUT                  104
#define ID_WV_NODE                      105
#define IDS_DEBUG                       106
#define IDS_EMAIL                       107
#define IDS_ENGINEINITERROR             108
#define IDS_ENGINELOADERROR             109
#define IDS_ENGINESAVEERROR             110
#define IDS_ENGINECORRUPTED             111
#define IDS_HOMEPAGE                    112
#define ID_WV_MODE                      113
#define ID_WV_SEL                       114
#define IDR_MAINFRAME                   128
#define IDR_FINDERTYPE                  129
#define IDD_NEWDLG                      131
#define IDR_TIMEBAR                     139
#define IDR_TOOLBAR                     141
#define IDD_HELPDLG                     146
#define IDC_MSX                         1000
#define IDC_MSY                         1001
#define IDC_MAPEDIT                     1001
#define IDC_MAPEDIT2                    1002
#define IDC_HEAPSIZE                    1004
#define IDC_WADD                        1004
#define IDC_MPCPT                       1005
#define IDC_WREMOVE                     1005
#define IDC_MWALKERS                    1006
#define IDC_MREQUESTS                   1007
#define IDC_MAXTC                       1008
#define IDC_SBC                         1009
#define IDC_PTIME                       1009
#define IDC_WBC                         1010
#define IDC_PSTATE                      1010
#define IDC_FSC                         1011
#define IDC_PSID                        1011
#define IDC_BC                          1012
#define IDC_PPATHS                      1012
#define IDC_HC                          1013
#define IDC_PENODES                     1013
#define IDC_DC                          1014
#define IDC_PREQ                        1014
#define IDC_ND                          1015
#define IDC_PMEM                        1015
#define IDC_PWAL                        1015
#define IDC_BFR                         1016
#define IDC_PPOS                        1016
#define IDC_BFS                         1017
#define IDC_WT                          1018
#define IDC_SHEAPSIZE                   1019
#define IDC_SMWALKERS                   1020
#define IDC_SMPCPT                      1021
#define IDC_SMREQUESTS                  1022
#define IDC_GMEMORY                     1023
#define IDC_GMAP                        1024
#define IDC_SMSX                        1025
#define IDC_SMSY                        1026
#define IDC_FSB                         1027
#define IDC_GHEUR                       1028
#define IDC_WSPEED                      1029
#define IDC_SHEUR                       1029
#define IDC_WCOLOR                      1030
#define IDC_MIXCOEF                     1030
#define IDC_WPRIORITY                   1031
#define IDC_GMIX                        1031
#define IDC_PSSPINX                     1032
#define IDC_SMIXFUNC                    1032
#define IDC_PSSPINY                     1033
#define IDC_DT                          1033
#define IDC_PENSEDITX                   1034
#define IDC_RSSPIN                      1035
#define IDC_PENSEDITY                   1036
#define IDC_RSEDIT                      1037
#define IDC_WTEXT                       1040
#define IDC_TIMEEDIT                    1041
#define IDC_TIMESPIN                    1042
#define IDC_SFSB                        1043
#define IDC_SSPEED                      1044
#define IDC_SPRIORITY                   1045
#define IDC_EMAIL                       1047
#define IDC_HEUR                        1050
#define IDC_EXPLORER                    1051
#define IDC_MIXFUNC                     1051
#define IDC_HHOME                       1052
#define IDC_EDRESET                     1054
#define IDC_SMIXCOEF                    1055
#define ID_CSTOP                        32774
#define ID_CSTEP                        32776
#define ID_CPLAY                        32777
#define ID_EDITMAP                      32778
#define ID_RAISEMAP                     32779
#define ID_LOWERMAP                     32780
#define ID_CONTROLMAP                   32781
#define ID_PARAM                        32782
#define ID_VIEW_GRID                    32784
#define ID_VIEWGRID                     59394

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        148
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1056
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
