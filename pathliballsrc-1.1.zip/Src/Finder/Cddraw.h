// CDDrawView.h : interface of the CCDDrawView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CDDRAWVIEW_H__EE1176F0_A85A_11D1_9000_B7E9E8834D23__INCLUDED_)
#define AFX_CDDRAWVIEW_H__EE1176F0_A85A_11D1_9000_B7E9E8834D23__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "stdafx.h"

class CCDDrawView : public CView
{
protected: // create from serialization only
        CCDDrawView();
        DECLARE_DYNCREATE(CCDDrawView)

        // Attributes
        LPDIRECTDRAW            lpDD;           // DirectDraw object
        LPDIRECTDRAWSURFACE     lpDDSPrimary;   // DirectDraw primary surface
        LPDIRECTDRAWSURFACE     lpDDSBack;      // DirectDraw back surface
        LPDIRECTDRAWPALETTE     lpDDPal;        // DirectDraw palette
		LPDIRECTDRAWCLIPPER     lpClipper;      // Clipper for primary
		LPDIRECTDRAWSURFACE     lpDDSOne;       // Offscreen surface 1
        LPDIRECTDRAWSURFACE     lpDDSHL;        // Horizontal line save
        LPDIRECTDRAWSURFACE     lpDDSVL;        // Horizontal line save


        BOOL                    bActive;        // is application active?
        BOOL                    bTapeFlag; 

public:

  // Operations
	BOOL GetOffsetDC(CDC *pDC,HDC* pHDC);
	void  ReleaseOffsetDC(CDC *pDC,HDC* pHDC);
	void  Offset2Screen(RECT* pRect,RECT* dRect);
	void  EraseSurface();
    void  RestoreSurfaces();

public:

// Overrides
        // ClassWizard generated virtual function overrides
        //{{AFX_VIRTUAL(CCDDrawView)
        public:
        void OnSize(UINT nType, int cx, int cy);
        virtual void OnDraw(CDC* pDC);  // overridden to draw this view
        virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
        virtual void OnInitialUpdate();
        virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
        protected:
        virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
        virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
        virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
        //}}AFX_VIRTUAL

// Implementation
public:
        virtual ~CCDDrawView();
#ifdef _DEBUG
        virtual void AssertValid() const;
        virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
        //{{AFX_MSG(CCDDrawView)
        afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	      //}}AFX_MSG
        DECLARE_MESSAGE_MAP()
};

////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CDDRAWVIEW_H__EE1176F0_A85A_11D1_9000_B7E9E8834D23__INCLUDED_)
