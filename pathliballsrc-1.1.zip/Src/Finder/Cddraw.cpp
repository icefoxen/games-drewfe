// CDDrawView.cpp : implementation of the CCDDrawView class
//

#include "stdafx.h"
#include "CDDraw.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCDDrawView

IMPLEMENT_DYNCREATE(CCDDrawView, CView)

BEGIN_MESSAGE_MAP(CCDDrawView, CView)
//{{AFX_MSG_MAP(CCDDrawView)
ON_WM_SIZE()
//	ON_WM_PAINT()
ON_WM_ERASEBKGND()
//}}AFX_MSG_MAP
// Standard printing commands
ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCDDrawView construction/destruction

CCDDrawView::CCDDrawView()
{
    // TODO: add construction code here
    lpDD = NULL;
    lpDDSPrimary=NULL;
    lpDDPal =NULL;
    lpDDSOne=NULL;
    lpDDSHL=NULL;
    lpDDSVL=NULL;
    bTapeFlag=FALSE;
    //	iShiftScreen=3;
}

CCDDrawView::~CCDDrawView()
{
    if( lpDD != NULL )
    {
        if( lpDDSPrimary != NULL )
        {
            lpDDSPrimary->Release();
            lpDDSPrimary = NULL;
        }
        if( lpDDPal != NULL )
        {
            lpDDPal->Release();
            lpDDPal = NULL;
        }
        if( lpDDSOne != NULL )
        {
            lpDDSOne->Release();
            lpDDSOne = NULL;
        }
        if( lpDDSHL != NULL )
        {
            lpDDSHL->Release();
            lpDDSHL = NULL;
        }
        if( lpDDSVL != NULL )
        {
            lpDDSVL->Release();
            lpDDSVL = NULL;
        }
        
        lpDD->Release();
        lpDD = NULL;
    }
}

BOOL CCDDrawView::PreCreateWindow(CREATESTRUCT& cs)
{
    // TODO: Modify the Window class or styles here by modifying
    //  the CREATESTRUCT cs
    
    return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CCDDrawView drawing

void CCDDrawView::OnDraw(CDC* pDC)
{
    
    // TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CCDDrawView printing

BOOL CCDDrawView::OnPreparePrinting(CPrintInfo* pInfo)
{
    // default preparation
    return DoPreparePrinting(pInfo);
}

void CCDDrawView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
    // TODO: add extra initialization before printing
}

void CCDDrawView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
    // TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CCDDrawView diagnostics

#ifdef _DEBUG
void CCDDrawView::AssertValid() const
{
    CView::AssertValid();
}

void CCDDrawView::Dump(CDumpContext& dc) const
{
    CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCDDrawView message handlers

void CCDDrawView::OnInitialUpdate()
{
    CView::OnInitialUpdate();
    
    HWND hwndTop = AfxGetMainWnd()->GetSafeHwnd();
    
    DDSURFACEDESC       ddsd;
    HRESULT             ddrval;
    CRect               mRect;
    
    ddrval = DirectDrawCreate(NULL, &lpDD, NULL);
    if( ddrval != DD_OK ) goto error;
    
    // Get normal mode
    ddrval = lpDD->SetCooperativeLevel( hwndTop, DDSCL_NORMAL );
    if(ddrval != DD_OK ) goto error;
    
    // Create the primary surface with one back buffer.
    memset( &ddsd, 0, sizeof( ddsd ) );
    ddsd.dwSize = sizeof(ddsd);
    ddsd.dwFlags = DDSD_CAPS;// | DDSD_BACKBUFFERCOUNT;
    ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;
    
    ddsd.dwBackBufferCount = 0;
    
    ddrval = lpDD->CreateSurface( &ddsd, &lpDDSPrimary, NULL );
    if( ddrval != DD_OK ) goto error;
    
    ddrval = lpDD->CreateClipper( 0, &lpClipper, NULL );
    if( ddrval != DD_OK ) goto error;

    ddrval = lpClipper->SetHWnd( 0,m_hWnd );
    if( ddrval != DD_OK ) goto error;
    
    ddrval = lpDDSPrimary->SetClipper( lpClipper );
    if( ddrval != DD_OK ) goto error;

    ZeroMemory(&ddsd, sizeof(ddsd));
    ddsd.dwSize = sizeof(ddsd);
    ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT |DDSD_WIDTH;
    ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
    ddsd.dwWidth = GetSystemMetrics(SM_CXFULLSCREEN); 
    ddsd.dwHeight = GetSystemMetrics(SM_CYFULLSCREEN); 
    ddrval=lpDD->CreateSurface(&ddsd,&lpDDSOne , NULL);
    if ( ddrval != DD_OK ) goto error;
    
    ddsd.dwSize = sizeof(ddsd);
    ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT |DDSD_WIDTH;
    ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
    ddsd.dwWidth = GetSystemMetrics(SM_CXFULLSCREEN); 
    ddsd.dwHeight = 2;
    ddrval=lpDD->CreateSurface(&ddsd,&lpDDSHL , NULL);
    if ( ddrval != DD_OK ) goto error;
    
    ddsd.dwSize = sizeof(ddsd);
    ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT |DDSD_WIDTH;
    ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
    ddsd.dwWidth = 2;
    ddsd.dwHeight = GetSystemMetrics(SM_CYFULLSCREEN);
    ddrval=lpDD->CreateSurface(&ddsd,&lpDDSVL , NULL);
    if ( ddrval != DD_OK ) goto error;
    
    // Prepare lookup table
    if (!DDCreateLookupTable(lpDDSOne)) MessageBox("Unable to prepare lookup table");
    
    return ;
    
error:
    AfxMessageBox( "DirectDraw Init FAILED");
    return ;
}

void CCDDrawView::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo)
{
    // TODO: Add your specialized code here and/or call the base class
    
    CView::OnPrepareDC(pDC, pInfo);
}

BOOL CCDDrawView::GetOffsetDC(CDC *pDC,HDC* pHDC)
{
    HRESULT ddRez;
    if (ddRez=lpDDSOne->GetDC(pHDC)==DD_OK)
    {
        pDC->Attach(*pHDC);
        return TRUE;
    }
    else return FALSE;
}


void CCDDrawView::RestoreSurfaces()
{
    if (lpDDSPrimary) lpDDSPrimary->Restore();    
    if (lpDDSOne) lpDDSOne->Restore();    
    if (lpDDSVL) lpDDSVL->Restore();    
    if (lpDDSHL) lpDDSHL->Restore();    
}

void CCDDrawView::OnSize(UINT nType, int cx, int cy) 
{
//    RestoreSurfaces();

    CView::OnSize(nType, cx, cy);
}

void  CCDDrawView::ReleaseOffsetDC(CDC *pDC,HDC* pHDC)
{
    pDC->Detach();
    lpDDSOne->ReleaseDC(*pHDC);
}
void CCDDrawView::EraseSurface()
{
    DDBLTFX ddbltfx;
    ddbltfx.dwSize = sizeof(ddbltfx);
    ddbltfx.dwFillColor = RGB(255,0,255);
    lpDDSOne->Blt(
        NULL,        // Destination
        NULL, NULL,  // Source rectangle
        DDBLT_COLORFILL, &ddbltfx);
}

void CCDDrawView::Offset2Screen(RECT* pRect,RECT* dRect) // invalid RECT , screenRect
{
    
    RECT destRect;
    POINT pt;
    destRect=*pRect;
    pt.x = dRect->left;
    pt.y = dRect->top;
    ::ClientToScreen( m_hWnd, &pt );
    ::OffsetRect(&destRect, pt.x, pt.y);
    lpDDSPrimary->Blt( &destRect, lpDDSOne, pRect, 0, NULL );
}

BOOL CCDDrawView::OnEraseBkgnd(CDC* pDC)
{
    return FALSE;
}
